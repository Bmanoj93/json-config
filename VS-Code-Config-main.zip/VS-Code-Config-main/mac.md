# Will add that soon!


## Pre-requirements

- coreutils for `timeout` command
  - install coreutils : `brew install coreutils`
- Java